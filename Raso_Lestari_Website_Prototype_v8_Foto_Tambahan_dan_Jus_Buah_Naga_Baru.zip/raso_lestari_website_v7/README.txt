Raso Lestari Website Prototype — Updated Menu Photos

File utama: index.html

Pembaruan:
- Menambahkan foto terbaru untuk 20 menu yang dikirim pengguna.
- Foto makanan/minuman disimpan di folder food_photos/.
- Data menu pada index.html telah diarahkan ke foto terbaru.
- Fitur pencarian, filter kategori, Info Gizi, Asal Kuliner, dan konsep visual ramah lingkungan tetap dipertahankan.

Cara membuka:
1. Ekstrak ZIP.
2. Buka raso_lestari_website/index.html di browser.
3. Pastikan folder food_photos berada di samping index.html.
